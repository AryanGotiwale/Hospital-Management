﻿namespace hospital
{
    partial class frmmain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.masterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.patientInfoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.admitInfoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.doctorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.doctor1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.doctor2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.doctor3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.wardsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ward1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iCUToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tabletInfoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Font = new System.Drawing.Font("Segoe UI Semibold", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.masterToolStripMenuItem,
            this.doctorToolStripMenuItem,
            this.wardsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 40);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // masterToolStripMenuItem
            // 
            this.masterToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.patientInfoToolStripMenuItem,
            this.admitInfoToolStripMenuItem,
            this.tabletInfoToolStripMenuItem});
            this.masterToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI Semibold", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.masterToolStripMenuItem.Name = "masterToolStripMenuItem";
            this.masterToolStripMenuItem.Size = new System.Drawing.Size(103, 36);
            this.masterToolStripMenuItem.Text = "Master";
            // 
            // patientInfoToolStripMenuItem
            // 
            this.patientInfoToolStripMenuItem.Name = "patientInfoToolStripMenuItem";
            this.patientInfoToolStripMenuItem.Size = new System.Drawing.Size(223, 36);
            this.patientInfoToolStripMenuItem.Text = "Patient Info";
            this.patientInfoToolStripMenuItem.Click += new System.EventHandler(this.patientInfoToolStripMenuItem_Click);
            // 
            // admitInfoToolStripMenuItem
            // 
            this.admitInfoToolStripMenuItem.Name = "admitInfoToolStripMenuItem";
            this.admitInfoToolStripMenuItem.Size = new System.Drawing.Size(223, 36);
            this.admitInfoToolStripMenuItem.Text = "Admit Info";
            // 
            // doctorToolStripMenuItem
            // 
            this.doctorToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.doctor1ToolStripMenuItem,
            this.doctor2ToolStripMenuItem,
            this.doctor3ToolStripMenuItem});
            this.doctorToolStripMenuItem.Name = "doctorToolStripMenuItem";
            this.doctorToolStripMenuItem.Size = new System.Drawing.Size(108, 36);
            this.doctorToolStripMenuItem.Text = "Doctor ";
            // 
            // doctor1ToolStripMenuItem
            // 
            this.doctor1ToolStripMenuItem.Name = "doctor1ToolStripMenuItem";
            this.doctor1ToolStripMenuItem.Size = new System.Drawing.Size(216, 36);
            this.doctor1ToolStripMenuItem.Text = "doctor 1";
            // 
            // doctor2ToolStripMenuItem
            // 
            this.doctor2ToolStripMenuItem.Name = "doctor2ToolStripMenuItem";
            this.doctor2ToolStripMenuItem.Size = new System.Drawing.Size(216, 36);
            this.doctor2ToolStripMenuItem.Text = "doctor 2";
            // 
            // doctor3ToolStripMenuItem
            // 
            this.doctor3ToolStripMenuItem.Name = "doctor3ToolStripMenuItem";
            this.doctor3ToolStripMenuItem.Size = new System.Drawing.Size(216, 36);
            this.doctor3ToolStripMenuItem.Text = "doctor 3";
            // 
            // wardsToolStripMenuItem
            // 
            this.wardsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ward1ToolStripMenuItem,
            this.iCUToolStripMenuItem});
            this.wardsToolStripMenuItem.Name = "wardsToolStripMenuItem";
            this.wardsToolStripMenuItem.Size = new System.Drawing.Size(95, 36);
            this.wardsToolStripMenuItem.Text = "Wards";
            // 
            // ward1ToolStripMenuItem
            // 
            this.ward1ToolStripMenuItem.Name = "ward1ToolStripMenuItem";
            this.ward1ToolStripMenuItem.Size = new System.Drawing.Size(246, 36);
            this.ward1ToolStripMenuItem.Text = "General Ward";
            // 
            // iCUToolStripMenuItem
            // 
            this.iCUToolStripMenuItem.Name = "iCUToolStripMenuItem";
            this.iCUToolStripMenuItem.Size = new System.Drawing.Size(246, 36);
            this.iCUToolStripMenuItem.Text = "ICU";
            // 
            // tabletInfoToolStripMenuItem
            // 
            this.tabletInfoToolStripMenuItem.Name = "tabletInfoToolStripMenuItem";
            this.tabletInfoToolStripMenuItem.Size = new System.Drawing.Size(223, 36);
            this.tabletInfoToolStripMenuItem.Text = "Tablet Info";
            // 
            // frmmain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmmain";
            this.Text = "frmmain";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmmain_Load);
            this.MdiChildActivate += new System.EventHandler(this.frmmain_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem masterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem patientInfoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem admitInfoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem doctorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem doctor1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem doctor2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem doctor3ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem wardsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ward1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iCUToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tabletInfoToolStripMenuItem;
    }
}