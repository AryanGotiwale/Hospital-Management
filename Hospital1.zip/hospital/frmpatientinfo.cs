﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hospital
{
    public partial class frmpatientinfo : Form
    {
        public frmpatientinfo()
        {
            InitializeComponent();
            DisplayData();
        }
        SqlConnection con = new SqlConnection("Data Source=LAPTOP-J5E2PU9O\\SQLEXPRESS;Initial Catalog=Hospital_Management;Integrated Security=true;");
        SqlCommand cmd;
        SqlDataAdapter adapt;
        private void DisplayData()
        {
            con.Open();
            DataTable dt = new DataTable();
            adapt = new SqlDataAdapter("select * from Patient_info", con);
            adapt.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        //Clear Data  
        private void ClearData()
        {
            txtname.Text = "";
            txtmiddlename.Text = "";
            txtaadhar.Text="";
            txtaddress.Text = "";
            txtage.Text = "";
            txtbg.Text = "";
            txtdistrict.Text = "";
            txtstate.Text = "";
            txttaluka.Text = "";
            txtsurname.Text = "";
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (txtname.Text != "" && txtmiddlename.Text != ""&&txtsurname.Text!=""&&txtaadhar.Text!=""&&txtaddress.Text!=""&&txtage.Text!="")
            {
                string sql = @"insert into dbo.Patient_info(Patient_Name,Patient_middlename,Patient_Surname,
                             Patient_Age,Patient_Bloodgroup,Patient_Address,Patient_State,Patient_Taluka,
                             Patient_District,Patient_Aadharno,Patient_Sex) values('" +
                             txtname.Text + "','" + txtmiddlename.Text + "','" + txtsurname.Text + "','" +
                             txtage.Text + "', '" +txtbg.Text +"','"+ txtaddress.Text +"','"+
                             txtstate.Text +"','"+ txttaluka.Text +"','"+ txtdistrict.Text+"','"+
                             txtaadhar.Text+"','"+cbsex.SelectedItem.ToString()+"')";


            

                cmd = new SqlCommand(sql,con);
                con.Open();
               

                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Record Inserted Successfully");
                DisplayData();
                ClearData();
            }
            else
            {
                MessageBox.Show("Please Provide Details!");
            }
        }
    }
}
