﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hospital
{
    public partial class frmmain : Form
    {
        public frmmain()
        {
            InitializeComponent();
        }

        private void patientInfoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmpatientinfo o = new frmpatientinfo();
            o.MdiParent = this;
            o.Show();
        }

        private void frmmain_Load(object sender, EventArgs e)
        {
            

        }
    }
}
