﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hospital
{
    public partial class frmlogin : Form
    {
        public frmlogin()
        {
            InitializeComponent();
        }

        private void btnlogin_Click(object sender, EventArgs e)
        {
            string user, pass;
            user = txtuser.Text;
            pass = txtpass.Text;
            if(user=="admin"&&pass=="pass1212")
            {
                MessageBox.Show("Login successfully", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                this.Hide();
                frmmain o = new frmmain();
                o.Show();
            }
            else
            {
                MessageBox.Show("Login failed", "", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
            }
        }
    }
}
